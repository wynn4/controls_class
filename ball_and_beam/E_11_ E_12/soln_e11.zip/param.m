% actual system parameters
AP.m1 = 0.35;  % kg
AP.m2 = 2;     % kg
AP.L = 0.5; % m
AP.g = 9.8; % m/s^2


% initial conditions
AP.theta0 = 0;
AP.thetadot0 = 0;
AP.y0 = 0;
AP.ydot0 = 0;

% parameters known to the controller
P.m1 = 0.35;  % kg
P.m2 = 2;     % kg
P.L = 0.5; % m
P.g = 9.8; % m/s^2

% PD design for inner loop
P.ze = P.L/2;
b0 = P.L/(P.m2*P.L^2/3+P.m1*P.ze^2);
tr_theta = 1;
wn_th    = 2.2/tr_theta;
P.kp_th  = wn_th^2/b0
P.kd_th  = 2*zeta_th*wn_th/b0;

% DC gain for inner loop
k_DC_th = 1;

%PD design for outer loop
tr_z     = 10*tr_theta;
zeta_z   = 0.707;
wn_z     = 2.2/tr_z;
P.kp_z   = -wn_z^2/P.g;
P.kd_z   = -2*zeta_z*wn_z/P.g;

